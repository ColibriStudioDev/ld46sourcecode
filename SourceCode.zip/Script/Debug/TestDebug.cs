﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestDebug : MonoBehaviour
{
    public MuscleCrushing crushing;
    private void Start()
    {



    }

}
