﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class DeathCounter 
{
    private static float deathNb;

    public static float DeathNb { get => deathNb; set => deathNb = value; }
}
